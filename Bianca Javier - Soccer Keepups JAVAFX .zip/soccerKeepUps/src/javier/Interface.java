package javier;

import java.util.HashSet;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Interface extends Application {
	
	//--- Screen size --- //
	private final int GAME_WIDTH = 800;
	private final int GAME_HEIGHT = 600;

	
	//--- Game states --- //
	private final int TITLE_SCREEN = 0;
	private final int PLAYING = 1;
	
	//--- Score --- //
	private int score = 0;
	private int highScore = 0;
	private Text scoreText = new Text("Score: " + score);
	
	
	//--- Button --- //
	Button exitButton = new Button("Exit");
	Button restartButton = new Button("Restart");
	
	
	private final HashSet <KeyCode> keyboard = new HashSet <KeyCode>();
	
	// DECLARE SPRITES
	 private Sprite ball = new Sprite(new Image("file:images/SoccerBall.png", 50, 0, true, true));
	 private Sprite shoe = new Sprite(new Image("file:images/SoccerShoe.png", 60, 0, true, true));
	 
	 private Group gameScreen = new Group(ball, shoe);
	 
	 private AnimationTimer gameTimer;
	 private long previousTime = -1;
	 
	 private Text title = new Text("Soccer Keep Ups!");
	 private Text subtitle = new Text ("Press Spacebar");
	 Group titleScreen = new Group(title, subtitle);
	 
	  private int gameState = TITLE_SCREEN;
	  

	  /**
	   * Set up the main interface
	   */
	public Interface() {
		ball.setPosition(GAME_WIDTH/2 - ball.getWidth()/2, 200);
		ball.setVelocityY(100);
		shoe.setPosition(GAME_WIDTH/2 - shoe.getWidth()/2, 500);
		gameTimer = new AnimationTimer() {
			public void handle (long currentTime) {
				// calculate the elapsed time
				double elapsedTime = (currentTime - previousTime) / 1000000000.0;
				// call the update method
				updateGame(elapsedTime);
				// save current time
				previousTime = currentTime;
			}
			
			public void start() {
				previousTime = System.nanoTime();
				super.start();
			}
			
			public void stop () {
				previousTime = -1;
				super.stop();
			}
		};
		
	}
	

	/**
	 * Set up groups, and text
	 */
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
		title.setFont(Font.font("Bahaus 93", 70));
		title.relocate(GAME_WIDTH/2 - title.getBoundsInParent().getWidth()/2, 100);
		title.setFill(Color.YELLOW);
		title.setStroke(Color.ROYALBLUE);
		title.setStrokeWidth(4);
		title.setEffect(new DropShadow());
		
		subtitle.setFont(Font.font("Cooper Black", 30));
		subtitle.relocate(GAME_WIDTH/2 - subtitle.getBoundsInParent().getWidth()/2, 350);
		subtitle.setFill(Color.YELLOW);
		subtitle.setStroke(Color.ROYALBLUE);
		subtitle.setStrokeWidth(2);
		subtitle.setEffect(new DropShadow());
		
	    scoreText.setFont(Font.font("Cooper Black", 20));
	    scoreText.setFill(Color.YELLOW);
	    scoreText.setStroke(Color.ROYALBLUE);
	    scoreText.setStrokeWidth(1);
	    scoreText.setEffect(new DropShadow());
	    scoreText.relocate(10, 20);
	    

	    gameScreen.getChildren().add(scoreText);
		
		Group root = new Group();
		root.getChildren().addAll(gameScreen, titleScreen);
		
		Scene gameScene = new Scene(root, GAME_WIDTH, GAME_HEIGHT, Color.GREEN);

		gameScene.setOnKeyPressed(key -> keyPressed(key));
		gameScene.setOnKeyReleased(key -> keyReleased(key));
		
		primaryStage.setScene(gameScene);
		primaryStage.setTitle("Keep ups!");
		primaryStage.setResizable(false);
		primaryStage.show();

	}

	/**
	 * Responds when a key is pressed
	 * @param key
	 */
	public void keyPressed(KeyEvent key) {
	    if (!keyboard.contains(KeyCode.P)) {
	        if (gameState == PLAYING) {
	            if (key.getCode() == KeyCode.P) {
	                pause();
	            }
	        }
	    }
	    if (key.getCode() == KeyCode.ESCAPE) {
	        Platform.exit();
	    }
	    if (!keyboard.contains(KeyCode.SPACE)) {
	        if (gameState == TITLE_SCREEN) {
	            if (key.getCode() == KeyCode.SPACE) {
	                startGame();
	            }
	        }
	    }
	    keyboard.add(key.getCode());
	}

	/**
	 * Responds when a key is released
	 * @param key
	 */
	public void keyReleased(KeyEvent key) {
		keyboard.remove(key.getCode());
	}
	
	
	/**
	 * updates the game
	 * @param elapsedTime
	 */
	public void updateGame (double elapsedTime) {
		ballPhysics(elapsedTime);
		handleKeyboardImport(elapsedTime);
		
	}

	/**
	 * Allows for right and left movement of the shoe
	 * @param elapsedTime
	 */
	public void handleKeyboardImport(double elapsedTime) {
		if (keyboard.contains(KeyCode.LEFT)) {
			shoe.setVelocityX(-200);	
			shoe.update(elapsedTime);
		}
		
		if (keyboard.contains(KeyCode.RIGHT)) {
			shoe.setVelocityX(200);	
			shoe.update(elapsedTime);
		}
	}
	
	/**
	 * Set up the physics of the ball
	 * @param elapsedTime
	 */
	public void ballPhysics(double elapsedTime) {
		ball.update(elapsedTime);
		
		// Check to make sure ball doesn't hit the screen border
		if (ball.getPositionX() < 0) {
			// Back the ball to prevent "weirdness"
			ball.update(-elapsedTime);
			ball.setVelocityX(-ball.getVelocityX());
			
		}
		
		if (ball.getPositionX() + ball.getWidth() > GAME_WIDTH) {
			// Back the ball to prevent "weirdness"
			ball.update(-elapsedTime);
			ball.setVelocityX(-ball.getVelocityX());
		}
		
		if (ball.getVelocityY() > 0 && ball.intersect(shoe)) {
			// Back the ball to prevent "weirdness"
			ball.update(-elapsedTime);
			// Make new velocity random
			double newVelY = -150 * Math.random() - 100;
			double newVelX = 500 * Math.random() - 250;
			// Set the new direction of the ball
			ball.setVelocity(newVelX, newVelY);
			
			// Increase the score when the balls hits the shoe
			score++;
			if (score > highScore) {
				highScore = score;
			}
			
			// Update score
			scoreText.setText("Score: " + score);
		}
		
		if (ball.getPositionY() > GAME_HEIGHT) {
			gameOver();
		}
		// Apply some gravity to make ball fall down
		ball.addVelocity(0, 100 * elapsedTime);
	}
	
	
	public boolean isPaused () {
		return previousTime == -1;
	}
	
	/**
	 * Playing the game
	 */
	public void startGame() {
	    score = 0;
	    gameState = PLAYING;
	    titleScreen.setVisible(false);
	    gameTimer.start();
	    scoreText.setVisible(true);

	    // Update score text to display the current score
	    scoreText.setText("Score: " + score);

	    // Update highScore text to display the current highScore
	    scoreText.setText("High Score: " + highScore);
	}

	/**
	 * Game is over, prompt user if they want to play again
	 */
	public void gameOver() {
	    titleScreen.setVisible(true);
	    subtitle.setVisible(false);
	    gameTimer.stop();
	    
	    // Reset the game and put sprites in original positions for the next game
	    ball.setPosition(GAME_WIDTH / 2 - ball.getWidth() / 2, 200);
	    ball.setVelocityX(0);
	    ball.setVelocityY(100);
	    shoe.setPosition(GAME_WIDTH / 2 - shoe.getWidth() / 2, 500);

	    Text gameOverText = new Text("Game over!\nScore: " + score + "\nHigh Score: " + highScore);
	    gameOverText.setFont(Font.font("Cooper Black", 30));
	    gameOverText.setFill(Color.YELLOW);
	    gameOverText.setStroke(Color.ROYALBLUE);
	    gameOverText.setStrokeWidth(2);
	    gameOverText.setEffect(new DropShadow());
	    gameOverText.relocate(GAME_WIDTH / 2 - gameOverText.getBoundsInParent().getWidth()/2 + 20, 290);

	    // Update the text content of gameOverText
	    gameOverText.setText("Play Again?");
	    
	    // Restart button
	    Button restartButton = new Button("Restart");
	    restartButton.setFont(Font.font("Cooper Black", 20));
	    restartButton.relocate(GAME_WIDTH / 2 - 70, 400);
	    restartButton.setOnAction(e -> startGame());
	    
	    // Exit Button
	    exitButton.setFont(Font.font("Cooper Black", 20));
	    exitButton.relocate(GAME_WIDTH / 2 + 20, 400);
	    exitButton.setOnAction(e -> Platform.exit());
	    
	    

	    titleScreen.getChildren().addAll(gameOverText, restartButton, exitButton);

	    gameState = TITLE_SCREEN;

	    // Reset the score for the next game
	    score = 0;
	}

	/**
	 * Pause the game, freezing everything in place
	 */
	public void pause() {
		if (isPaused()) {
			gameTimer.start();
			
		} else {
			gameTimer.stop();
		}
	}
	
	public static void main(String[] args) {launch();}
}

